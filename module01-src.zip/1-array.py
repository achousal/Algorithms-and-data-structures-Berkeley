#!/usr/bin/env python
# coding: utf-8

# initialization

# In[ ]:


from dsa.array import Array

a = Array([1, 1, 2, 3, 5, 8])
print(a)


# In[ ]:


a.count


# indexing

# In[ ]:


a[0]


# In[ ]:


a[1] = 10


# In[ ]:


print(a)


# insert

# In[ ]:


a.insert(0, -1)
print(a)


# In[ ]:


a.insert(3, -10)
print(a)


# delete

# In[ ]:


a.delete(3)
a.delete(0)
a


# out of bounds

# In[ ]:


for _ in range(10):
    a.append(100)


# In[ ]:





# In[ ]:




