#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from dsa.array import Array
a = Array([20, 5, -3, 8, 2, 14, 42, 7, 11, 13])


# linear search

# In[ ]:


def lsearch(array, target):
    for i in range(array.count):
        if array[i] == target:
            return i
    return -1


# In[ ]:


lsearch(a, 2)


# In[ ]:


lsearch(a, 20)


# In[ ]:


lsearch(a, 13)


# In[ ]:


lsearch(a, 100)


# In[ ]:


a = Array([1, 2, 3, 5, 6, 10, 15])


# In[ ]:


lsearch(a, 0)


# In[ ]:


lsearch(a, 15)


# In[ ]:


lsearch(a, 100)


# In[ ]:





# In[ ]:


from dsa.array import DynamicArray
da = DynamicArray([1, 2, 3, 5, 6, 10, 15])


# In[ ]:


lsearch(da, 0)


# In[ ]:


lsearch(a, 15)


# In[ ]:


lsearch(a, 100)


# binary search

# In[ ]:


def bsearch(array, target, debug=False):
    start = 0
    end = array.count - 1

    while start <= end:
        middle = (start + end) // 2
        if debug:
            print(start, end, middle, sep='\t')
            print(array[start:middle], array[middle], array[middle:end+1], sep='\t')
        if array[middle] == target:
            return middle
        elif array[middle] > target:
            end = middle - 1
        elif array[middle] < target:
            start = middle + 1
    return -1


# In[ ]:


a


# In[ ]:


bsearch(a, 6)


# In[ ]:


bsearch(a, 1)


# In[ ]:


bsearch(a, 100)


# In[ ]:


bsearch(a, 100, debug=True)


# does not work with unsorted array

# In[ ]:


da = DynamicArray([15, 10, 1, 6, 3, 5])


# In[ ]:


bsearch(da, 1)


# In[ ]:


bsearch(da, 2)


# In[ ]:


bsearch(da, 15)


# In[ ]:


bsearch(da, 10)


# In[ ]:


bsearch(da, 6)


# linear search vs binary search performance

# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'lsearch(a, 2)\n')


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'bsearch(a, 2)\n')


# In[ ]:


import random

temp_array = []
for _ in range(1_000_000):
    n = random.randint(0, 100_000_000)
    temp_array.append(n)

temp_array.sort()
large_array = DynamicArray(temp_array)
len(large_array)


# In[ ]:


for i in range(15):
    print(large_array[i])


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'lsearch(large_array, 1234567)\n')


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'bsearch(large_array, 1234567)\n')


# In[ ]:





# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'lsearch(large_array, 10)\n')


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'bsearch(large_array, 10)\n')


# search for a value that exists somewhere in the beginning

# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'lsearch(large_array, 1014)\n')


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'bsearch(large_array, 1014)\n')


# search for a value that exists somewhere at the end

# In[ ]:


len(large_array)


# In[ ]:


large_array[900_000]


# In[ ]:





# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'lsearch(large_array, 90022704)\n')


# In[ ]:


get_ipython().run_cell_magic('timeit', '', 'bsearch(large_array, 90022704)\n')


# In[ ]:




