#!/usr/bin/env python
# coding: utf-8

# In[1]:


paper_thickness = .1 #mm
earth_to_moon = 384000 #km

2 ** 42


# In[2]:


2 ** 42


# In[4]:


for i in range(100):
    print(i)


# In[10]:


n = 5_000_000
total = 0
for i in range(1, n + 1):
    total += i
print(total)


# In[11]:


n * (n + 1) / 2


# In[17]:


from dsa import DynamicArray
da = DynamicArray([1, 1, 2, 3, 5, 8, 13, 21])
da


# In[19]:


rev_da = DynamicArray()

for i in range(len(da)):
    rev_da.insert(0, da[i])
    
print(rev_da)


# In[23]:


list(reversed(list(reversed(rev_da))))


# In[ ]:




