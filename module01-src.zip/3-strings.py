#!/usr/bin/env python
# coding: utf-8

# In[ ]:


string = "This is a string"
target = "is"

def search(string, target):
    n = len(string)
    m = len(target)

    for i in range(0, n - m + 1):
        j = 0
        while j < m and target[j] == string[i + j]:
            j = j + 1
        if j == m:
            return i
    return -1

ix = search(string, target)
print(string[ix])


# In[ ]:




