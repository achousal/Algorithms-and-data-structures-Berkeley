#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from dsa.DynamicArray import DynamicArray
da = DynamicArray([1, 1, 2, 3, 5, 8, 13, 21])
da


# insert

# In[ ]:


da.insert(0, -4)
print(da)
da.insert(3, 99)
print(da)


# In[ ]:


da.insert(5, 88)


# In[ ]:


da


# In[ ]:


for i in range(0, 5):
    da.insert(i, i * 10)
    print(da)


# delete

# In[ ]:


da.delete(3)
da.delete(0)
da


# no more out of bounds for append

# In[ ]:


for _ in range(5):
    da.append(100)
da


# shrink

# In[ ]:


da


# In[ ]:


da.delete(12)


# In[ ]:


da


# In[ ]:


da.delete(11)


# In[ ]:


da


# In[ ]:


da.delete(7)


# In[ ]:


da


# In[ ]:


da.delete(9)


# In[ ]:


da


# In[ ]:




