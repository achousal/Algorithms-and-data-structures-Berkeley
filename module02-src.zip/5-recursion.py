#!/usr/bin/env python
# coding: utf-8

# any iterative algorithm can be written recursively

# In[ ]:


def factorial(n):
    fact = 1
    for i in range(2, n + 1):
        fact *= i
    return fact

factorial(5)


# In[ ]:


def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

factorial(5)


# #### sum

# In[ ]:


def mysum(array):
    total = 0
    for n in array:
        total += n
    return total

mysum([1, 2, 3, 10])


# In[ ]:


def mysum(array):
    if len(array) == 0:
        return 0
    return array[0] + mysum(array[1:])

mysum([1, 2, 3, 10])


# search

# In[ ]:


def search(array, target, i=0):
    for i in range(len(array)):
        if array[i] == target:
            return i
    return -1
search([1, 2, 3, 4, 5], 7)


# In[ ]:


def search(array, target, i=0):
    if i >= len(array):
        return -1

    if array[i] == target:
        return i
    else:
        return search(array, target, i + 1)

print(search([10, 20, 30, 40, 50], 50))
print(search([10, 20, 30, 40, 50], 100))


# In[ ]:


def search(array, target, i=0):
    if len(array) == 0:
        return -1

    if array[0] == target:
        return i
    else:
        return search(array[1:], target, i + 1)

print(search([10, 20, 30, 40, 50], 50))
print(search([10, 20, 30, 40, 50], 100))


# GCD (greatest common divisor)

# recursive version of Euclid's algorithm
# https://en.wikipedia.org/wiki/Euclidean_algorithm

# In[25]:


import math
def gcd(a, b):
    if b == 0:
        return a
    else:
        return gcd(b, a % b)

test_numbers = [ (10, 1), (10, 2), (10, 3), (10, 5),
                 (5, 10), (144, 24), (12, 144), (17, 9)]
for a, b in test_numbers:
    print(gcd(a, b), math.gcd(a, b))


# iterative version (inefficient)

# In[26]:


def gcd(a, b):
    gcd_value = 1
    for i in range(1, a + b):
        if a % i  == 0 and b % i == 0:
            gcd_value = i
    return gcd_value

test_numbers = [ (10, 1), (10, 2), (10, 3), (10, 5),
                 (5, 10), (144, 24), (12, 144), (17, 9)]
for a, b in test_numbers:
    print(gcd(a, b), math.gcd(a, b))


# iterative version of Euclid's algorithm

# In[27]:


def gcd(a, b):
    while b != 0:
        a, b = b, a % b

    return a

test_numbers = [ (10, 1), (10, 2), (10, 3), (10, 5),
                 (5, 10), (144, 24), (12, 144), (17, 9)]
for a, b in test_numbers:
    print(gcd(a, b), math.gcd(a, b))


# In[ ]:




